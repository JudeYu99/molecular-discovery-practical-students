DAY 2 SAMPLE DATA

Worked system
The receptor is the hydrogenated c-Abl kinase structure used in the official AutoDock Vina flexible docking tutorial. The deposited structure is PDB 1FPU. The worked activity uses the kinase pocket around the original ligand site.

Files
1fpu_receptorH.pdb is the prepared protein receptor.
imatinib.smi is the expected binder used for the worked cross-docking example.
caffeine_decoy.smi is a simple physicochemical comparison decoy.
focused_box.json records the starting focused box.
student_record_sheet.csv provides a place to record results.

Suggested activity
1. Inspect the receptor and assess the known site with ProteinsPlus and DoGSite3.
2. Run focused docking with imatinib using the supplied box.
3. Download the results and record the best score and selected pose.
4. Repeat with caffeine using exactly the same settings.
5. Compare the two scores, pose locations and ContactCanvas interaction diagrams.
6. Run a blind imatinib search and compare the site placement and run time.
7. Minimise one selected imatinib pose.
8. Compare ContactCanvas diagrams before and after minimisation.

Interpretation
Caffeine is included to produce a clear teaching contrast. It is not a validated inactive control for c-Abl. The two ligands also differ greatly in size and chemical complexity. A more favourable Vina score or a larger interaction count does not establish binding or biological activity.

Source and credit
The receptor file is distributed by the AutoDock Vina project in its flexible docking example.
https://github.com/ccsb-scripps/AutoDock-Vina/tree/develop/example/flexible_docking
